PROYEK ANDROID — LAPORAN UANG MAKAN KP 2251

Isi:
- Aplikasi Android WebView yang memuat file HTML laporan uang makan KP2251 secara offline.
- Data penyimpanan browser (localStorage/IndexedDB) akan tersimpan di instalasi aplikasi pada perangkat tersebut.
- Ini belum berupa APK siap pasang; ini adalah proyek sumber untuk dibuka dan dibangun dengan Android Studio.

Cara membangun APK:
1. Pasang Android Studio di komputer/laptop.
2. Buka Android Studio > Open, pilih folder KP2251_APK_Project.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio memasang Android SDK yang diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Setelah selesai, tekan Locate untuk menemukan file APK.
6. Pindahkan APK ke HP Android dan buka untuk memasangnya. Jika diminta, izinkan instalasi dari sumber tersebut.

Catatan penting:
- Data aplikasi tersimpan lokal di HP yang menjalankan aplikasi, tidak otomatis tersinkron ke HP lain.
- Untuk berbagi data lintas perangkat diperlukan backend/server online.
- Fitur berbagi WhatsApp pada proyek ini menyediakan jembatan berbagi teks; berbagi gambar laporan mengikuti kemampuan HTML/browser yang digunakan.
- Nama aplikasi: Laporan Uang Makan KP2251.
- Pengembang sesuai permintaan: Ahmat Rajjab.

CARA MEMBANGUN APK DARI HP SAJA (TANPA ANDROID STUDIO):
1. Ekstrak ZIP ini jika memungkinkan, lalu unggah seluruh isi folder proyek ke repositori GitHub baru bernama KP2251-APK. Cara paling mudah adalah membuat repositori GitHub lalu mengunggah file proyek melalui browser.
2. Pastikan folder .github/workflows/build-apk.yml ikut terunggah. Jika tidak terlihat, aktifkan opsi tampilkan file tersembunyi atau unggah file workflow secara terpisah.
3. Buka tab Actions di repositori GitHub. Pilih workflow "Build APK KP2251", lalu tekan Run workflow.
4. Tunggu proses selesai. Buka hasil run yang hijau, gulir ke bagian Artifacts, lalu unduh "Laporan-Uang-Makan-KP2251-APK.zip".
5. Ekstrak ZIP artifact di HP. File app-debug.apk di dalamnya adalah APK untuk dipasang.

Catatan: langkah GitHub ini memerlukan akun GitHub dan koneksi internet. Saya tidak bisa menjalankan build jarak jauh atau mengunggah ke akun GitHub milik Anda dari percakapan ini.
\n\nPERBAIKAN FOTO NOTA v1.2\n- Pemilih foto Android menggunakan ACTION_OPEN_DOCUMENT dengan dukungan pilih banyak file.\n- Hasil pilihan banyak foto dari galeri/file manager diteruskan satu per satu ke WebView.\n- Form memberi pesan jika file bukan gambar atau foto gagal dibaca.\n