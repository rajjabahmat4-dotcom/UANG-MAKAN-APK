package com.ahmatrajjab.kp2251;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.widget.Toast;
import android.provider.MediaStore;
import android.os.Build;
import android.content.ContentValues;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.util.Base64;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 101;
    private static final int SAVE_FILE_REQUEST = 102;
    private byte[] pendingBytes;
    private String pendingMime, pendingName;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this); setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true); settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true); settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    // Use Android's document picker explicitly; supports gallery/files and multi-select.
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] accept = params.getAcceptTypes();
                    String mime = "*/*";
                    if (accept != null && accept.length > 0) {
                        for (String type : accept) {
                            if (type != null && !type.trim().isEmpty()) {
                                mime = type.trim();
                                break;
                            }
                        }
                    }
                    intent.setType(mime);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException | SecurityException e) {
                    try {
                        Intent fallback = params.createIntent();
                        startActivityForResult(fallback, FILE_CHOOSER_REQUEST);
                    } catch (Exception fallbackError) {
                        filePathCallback = null;
                        callback.onReceiveValue(null);
                        Toast.makeText(MainActivity.this, "Galeri/pemilih file tidak dapat dibuka. Coba gunakan aplikasi Galeri atau File Manager.", Toast.LENGTH_LONG).show();
                    }
                }
                return true;
            }
        });
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class ShareBridge {
        @JavascriptInterface public void saveFile(String name, String mime, String base64) {
            try {
                pendingName = safeName(name); pendingMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                pendingBytes = Base64.decode(base64, Base64.DEFAULT);
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType(pendingMime);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingName);
                    try { startActivityForResult(intent, SAVE_FILE_REQUEST); }
                    catch (ActivityNotFoundException e) { pendingBytes = null; toast("Tidak dapat membuka penyimpanan berkas."); }
                });
            } catch (Exception e) { toast("Gagal menyiapkan berkas."); }
        }
        @JavascriptInterface public void shareFile(String name, String mime, String base64, String text) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, safeName(name));
                try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".provider", f);
                Intent intent = new Intent(Intent.ACTION_SEND); intent.setType(mime == null ? "application/octet-stream" : mime);
                intent.putExtra(Intent.EXTRA_STREAM, uri); intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> { try { startActivity(Intent.createChooser(intent, "Bagikan menggunakan")); }
                    catch (ActivityNotFoundException e) { toast("Tidak ada aplikasi untuk membagikan berkas."); } });
            } catch (Exception e) { toast("Gagal menyiapkan berkas untuk dibagikan."); }
        }
        @JavascriptInterface public void openWhatsApp(String text) {
            runOnUiThread(() -> { try {
                Intent intent = new Intent(Intent.ACTION_SEND); intent.setType("text/plain");
                intent.setPackage("com.whatsapp"); intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text); startActivity(intent);
            } catch (ActivityNotFoundException e) { toast("WhatsApp tidak ditemukan. Silakan pasang WhatsApp."); } });
        }
    }
    private String safeName(String name) { if (name == null || name.trim().isEmpty()) return "berkas-kp2251"; return name.replaceAll("[^A-Za-z0-9._-]", "_"); }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show()); }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[] { data.getData() };
                    } else {
                        results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                    }
                }
                filePathCallback.onReceiveValue(results); filePathCallback = null;
            }
        } else if (requestCode == SAVE_FILE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) { out.write(pendingBytes); toast("Berkas berhasil disimpan."); }
                    else toast("Tidak dapat menulis berkas.");
                } catch (Exception e) { toast("Gagal menyimpan berkas."); }
            }
            pendingBytes = null; pendingName = null; pendingMime = null;
        }
    }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
