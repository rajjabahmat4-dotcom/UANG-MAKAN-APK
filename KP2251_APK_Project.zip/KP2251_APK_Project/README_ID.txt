PROYEK ANDROID — L.U.M (LAPORAN UANG MAKAN) KP 2251
Versi proyek perbaikan: 1.1
Pengembang: Ahmat Rajjab

PERBAIKAN DALAM VERSI INI
- Pesan yang jelas jika tombol berbagi rekap ditekan saat bulan terpilih belum memiliki transaksi.
- Pemeriksaan jika gambar rekap/transaksi gagal dibuat.
- Penanganan kesalahan saat membuat cadangan data.
- Workflow GitHub Actions diperjelas dan artifact APK tersedia untuk diunduh selama 14 hari.

FITUR
- Catat pemasukan dan pengeluaran, tanggal, keterangan, dan foto nota lebih dari satu.
- Rekap bulanan otomatis.
- Transaksi tanggal 25 sampai akhir bulan masuk ke rekap bulan berikutnya.
- Cari dan saring transaksi, hapus transaksi, serta hapus seluruh transaksi pada bulan terpilih.
- Simpan foto nota, buat cadangan JSON, dan pulihkan cadangan.
- Bagikan gambar rekap lewat menu berbagi Android; pilih WhatsApp bila tersedia.
- Data disimpan lokal di aplikasi/perangkat, tidak otomatis tersinkron ke perangkat lain.

CARA MEMBUAT APK DARI HP ANDROID (DENGAN GITHUB)
1. Ekstrak ZIP proyek ini menggunakan aplikasi pengelola file.
2. Buat repositori baru di GitHub, misalnya KP2251-APK.
3. Unggah seluruh isi folder KP2251_APK_Project ke repositori (termasuk folder tersembunyi .github).
   Pastikan file settings.gradle, build.gradle, folder app, dan .github/workflows/build-apk.yml berada di akar repositori.
4. Buka repositori di GitHub, masuk ke tab Actions, lalu pilih workflow “Build APK KP2251”.
5. Tekan Run workflow dan tunggu sampai proses selesai dengan tanda centang hijau.
6. Buka halaman hasil workflow yang berhasil, cari bagian Artifacts, lalu unduh “Laporan-Uang-Makan-KP2251-APK”. GitHub akan mengunduh ZIP artifact.
7. Ekstrak ZIP artifact. Di dalamnya terdapat app-debug.apk.
8. Ketuk app-debug.apk untuk memasang. Jika Android meminta izin, izinkan instalasi aplikasi dari sumber yang digunakan.

CARA MEMBUAT APK DI KOMPUTER
1. Pasang Android Studio dan Android SDK yang sesuai.
2. Buka folder KP2251_APK_Project di Android Studio dan tunggu Gradle Sync.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Setelah berhasil, tekan Locate untuk menemukan app-debug.apk.

CATATAN PENTING
- ZIP ini adalah proyek sumber yang diperbaiki, bukan APK siap pasang.
- APK debug belum ditandatangani untuk distribusi resmi Play Store.
- Workflow GitHub membutuhkan akun GitHub dan koneksi internet; build harus dijalankan di akun Anda.
- Foto berukuran besar dapat memenuhi penyimpanan. Buat cadangan berkala.
- Jangan menghapus data aplikasi atau mencopot pemasangan sebelum membuat cadangan, karena data lokal bisa hilang.
